package pk.Tools;
import javax.swing.*;
import  pk.Tools.KeyboardAction.*;
import pk.*;

/**
 *  Reource class for static variables 
 *  @author Rahul B.
 * @version 0.1.
 */
public class Resource
{
   public static JFrame frame;
   public static Turtle turtle = new Turtle();
   public static Canvas c;
}
