package pk.Tools.KeyboardAction;


/**
 * Turtle Properties like position,rotation,etc.
 * 
 * @author Rahul B.
 * @version 0.1.
 */
public class Turtle
{
    
    public int x=50,y=50
    ,speed=1   //Distance incrementer
    ,angle_inc=1
    ,px=50
    ,py=50;
    public double angle= 0;
    public boolean pu = true;//Pen up true or false

    
}
